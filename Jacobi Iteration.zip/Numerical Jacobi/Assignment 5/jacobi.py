import pandas as pd
import re
import numpy as np
from click._compat import raw_input
import sys

if __name__ == '__main__':
#-------------------------------- Parsing Part ---------------------------------

    regex = r'([+-]?\d*)([A-Z]|[a-z]\d*)'
    regex = re.compile(regex)
    input = open("input.txt", "r")

    coeff = []
    b = []
    for line in input:
        line = line.strip().replace(' ', '')
        l, r = line.split('=')
        c_temp = {}
        for sign, pos in regex.findall(l):
            if sign == '-':
                coff_sign = -1.0
            elif sign == '' or sign == '+':
                coff_sign = 1.0
            else:
                coff_sign = float(sign)

            c_temp[pos] = coff_sign
        b.append(r)
        coeff.append(c_temp)
    input.close()

    p = coeff
    q = b
    b = np.array(b, dtype='float')
    A = pd.DataFrame(p)
    A.fillna(0, inplace=True)
    A = A.values

#--------------------------------- Jacobi Part --------------------------------------

    newX = np.zeros(len(A[0]))
    x = list()
    print("Enter initial guesses:\n")

    for i in range(len(A[0])):

        input = raw_input()
        x.append(int(input))

    file = open('output1.txt', 'w')

    for k in range(0, 25, 1):

        for i in range(0, len(b), 1):

            if A[i][i] == 0:
                print("Can't Solve Using Jacobi Iteration Method, Division by Zero Occured\n")
                sys.exit()

            sum = 0
            for j in range(0, len(b), 1):

                if i != j:
                    sum = sum + A[i][j] * x[j]

            newX[i] = (b[i] - sum) / A[i][i]

        print("Iteration: " + str(k))
        file.write("Iteration:" + str(k) + '\n')

        for i in range(len(newX)):

            print(newX[i])
            file.write(str(newX[i]) + '\n')

        print("Error " + str(k))
        file.write("Error " + str(k) + '\n')

        for i in range(len(newX)):

            error = abs(((newX[i] - x[i]) / newX[i])) * 100
            print(str(error) + "%")
            file.write(str(error) + "%" + '\n')
            x[i] = newX[i]
