import re
import numpy as np
import pandas as pd

if __name__ == '__main__':
    regex = r'([+-]?\d*)([A-Z]|[a-z]\d*)'
    regex = re.compile(regex)
    input = open("input.txt", "r")

    coeff = []
    b = []
    for line in input:
        line = line.strip().replace(' ', '')
        l, r = line.split('=')

        c_temp = {}
        for sign, pos in regex.findall(l):
            if sign == '-':
                coff_sign = -1.0
            elif sign == '' or sign == '+':
                coff_sign = 1.0
            else:
                coff_sign = float(sign)

            c_temp[pos] = coff_sign
        b.append(r)
        coeff.append(c_temp)
    input.close()

    p = coeff
    q = b

    b = np.array(b, dtype='float').reshape(len(b), 1)
    A = pd.DataFrame(p)
    A.fillna(0, inplace=True)
    x = list(A.columns.values)
    A = A.values
    b = np.ravel(b)
    if A.shape[1] != b.shape[0] and A.shape[0] != A.shape[1]:
        raise ValueError("Not Square!")
    val = np.zeros((1, len(b)))
    detOfA = np.linalg.det(A)
    if detOfA == 0:
        raise ValueError("Determinant is Zero!!")

    for i in range(len(b)):
        arr = np.copy(A)
        arr[:, i] = b
        detOfA_tmp = np.linalg.det(arr)
        val[0][i] = detOfA_tmp / detOfA

    file = open('output1.txt', 'w')
    for i in range(len(b)):
        print(str(x[i]) + "=" + str(val[0][i]) + '\n')
        file.write(str(x[i]) + "=" + str(val[0][i]) + '\n')
