import re
import numpy as np
import pandas as pd

if __name__ == '__main__':
    regex=r'([+-]?\d*)([A-Z]|[a-z]\d*)'
    regex = re.compile(regex)
    input = open("input.txt", "r")

    coeff = []
    b = []
    for line in input:
        line = line.strip().replace(' ', '')
        l, r = line.split('=')

        c_temp = {}
        for sign, pos in regex.findall(l):
            if sign == '-':
                coff_sign = -1.0
            elif sign == '' or sign == '+':
                coff_sign = 1.0
            else:
                coff_sign = float(sign)

            c_temp[pos] = coff_sign
        b.append(r)
        coeff.append(c_temp)
    input.close()

    p = coeff
    q = b
    b = np.array(b, dtype='float').reshape(len(b), 1)
    A = pd.DataFrame(p)
    A.fillna(0, inplace=True)
    x = list(A.columns.values)
    A = A.values

    detOfA = np.linalg.det(A)
    if detOfA == 0:
        raise ValueError("Determinant is Zero! So, Not invertible")
    if A.shape[0] != A.shape[1]:
        raise ValueError("Not square! Unable to run method!")
    rows = A.shape[0]

    A = np.concatenate((A, np.identity(rows, dtype='float')), axis=1)

    for i in range(rows - 1):
        for row in range(i + 1, rows):
            coeff_L = A[row, i] / A[i, i]
            A[row, i:] = A[row, i:] - coeff_L * A[i, i:]

    for i in reversed(range(rows)):
        A[i, :] = A[i, :] / A[i, i]
        for row in reversed(range(0, i)):
            coeff_L = A[row, i] / A[i, i]
            A[row, i:] = A[row, i:] - coeff_L * A[i, i:]

    val = np.dot(A[:, rows:], b)
    file = open('output2.txt', 'w')
    for i in range(len(b)):
        print(str(x[i]) + "=" + format(float(val[i, 0]), '.2f') + '\n')
        file.write(str(x[i]) + "=" + format(float(val[i, 0]), '.2f') + '\n')
