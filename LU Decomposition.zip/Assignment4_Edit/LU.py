import scipy.linalg
import re
import numpy as np
import pandas as pd


if __name__ == '__main__':
    regex = r'([+-]?\d*)([A-Z]|[a-z]\d*)'
    regex = re.compile(regex)
    input = open("input.txt", "r")

    coeff = []
    b = []
    for line in input:
        line = line.strip().replace(' ', '')
        l, r = line.split('=')

        c_temp = {}
        for sign, pos in regex.findall(l):
            if sign == '-':
                coff_sign = -1.0
            elif sign == '' or sign == '+':
                coff_sign = 1.0
            else:
                coff_sign = float(sign)

            c_temp[pos] = coff_sign
        b.append(r)
        coeff.append(c_temp)
    input.close()

    p = coeff
    q = b

    b = np.array(b, dtype='float').reshape(len(b), 1)
    A = pd.DataFrame(p)
    A.fillna(0, inplace=True)
    x = list(A.columns.values)
    A = A.values

    print("--------------------------")
    P, L, U = scipy.linalg.lu(A)
    print(P)
    print(L)
    print(U)
    LU = scipy.linalg.lu_factor(A)
    print(LU)
    x_sol = scipy.linalg.lu_solve(LU, b)

    file = open('output3.txt', 'w')
    for i in range(len(b)):
        print(str(x[i]) + "=" + str(x_sol[i]) + '\n')
        file.write(str(x[i]) + "=" + str(x_sol[i]) + '\n')

